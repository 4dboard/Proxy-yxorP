function createEl(b, c) {
    let a = document.createElement("div");
    a.innerHTML = c, a.className = b, document.body.appendChild(a)
}

window.addEventListener("load", e => {
    let c = document.querySelectorAll("[data-bi]");
    for (i = 0; i < c.length; i++) c[i].style = 'background-image: url("https://data.xn--ply-onb.com/images/hp/' + c[i].getAttribute("data-bi");
    let b = document.querySelectorAll(".lazy-image");
    for (i = 0; i < b.length; i++) b[i].classList.remove("lazy-image"), b[i].src = "https://data.xn--ply-onb.com/images/webp/" + b[i].getAttribute("data-src");
    let d = document.querySelector("#swfGame");
    if (d) {
        let a = document.createElement("iframe");
        a.src = d.getAttribute("data-url"), a.id = "#swfGame", a.id = "ls center-block", a.style = "width: 100%; height: 588px;border:none", d.remove(), document.querySelector("#game-frame").appendChild(a)
    }
    document.querySelector(".inp__submit") && (document.querySelector(".inp__submit").innerHTML = "GO"), document.querySelector("#form-search").setAttribute("action", "/search"), document.querySelector("#form-search").setAttribute("method", "get"), document.querySelector(".icon-svg--cube-3d").classList.add("don")
})
