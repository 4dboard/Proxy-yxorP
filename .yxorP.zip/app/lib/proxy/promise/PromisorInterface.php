<?php namespace yxorP\app\lib\proxy\Promise;
interface PromisorInterface
{
    public function promise();
}
