<?php namespace yxorP\app\lib\proxy\Promise;
class CancellationExceptionA extends ARejectionException
{
}
