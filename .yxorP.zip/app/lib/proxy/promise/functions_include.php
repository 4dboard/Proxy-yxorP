<?php if (!function_exists('yxorP\app\lib\proxy\Promise\promise_for')) {
    require __DIR__ . '/functions.php';
}
