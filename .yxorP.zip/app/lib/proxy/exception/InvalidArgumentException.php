<?php namespace yxorP\app\lib\proxy\Exception;
final class InvalidArgumentException extends \InvalidArgumentException implements ProxyException
{
}
