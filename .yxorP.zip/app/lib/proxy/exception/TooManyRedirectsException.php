<?php namespace yxorP\app\lib\proxy\Exception;
class TooManyRedirectsException extends ARequestExceptionAA
{
}
