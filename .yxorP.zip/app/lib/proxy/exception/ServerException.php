<?php namespace yxorP\app\lib\proxy\Exception;
class ServerException extends BadResponseException
{
}
