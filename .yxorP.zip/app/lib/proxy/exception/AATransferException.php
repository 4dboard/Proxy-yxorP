<?php namespace yxorP\app\lib\proxy\Exception;

use RuntimeException;

class AATransferException extends RuntimeException implements ProxyException
{
}
