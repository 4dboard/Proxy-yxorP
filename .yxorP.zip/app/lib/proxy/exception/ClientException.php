<?php namespace yxorP\app\lib\proxy\Exception;
class ClientException extends BadResponseException
{
}
