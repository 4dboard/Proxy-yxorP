<?php if (!function_exists('yxorP\app\lib\proxy\uri_template')) {
    require __DIR__ . '/functions.php';
}
