<?php if (!function_exists('yxorP\app\lib\proxy\Psr7\str')) {
    require __DIR__ . '/functions.php';
}
