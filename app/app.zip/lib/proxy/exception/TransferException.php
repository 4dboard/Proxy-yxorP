<?php namespace yxorP\app\lib\proxy\exception;

use RuntimeException;

class transferException extends RuntimeException implements proxyException
{
}
