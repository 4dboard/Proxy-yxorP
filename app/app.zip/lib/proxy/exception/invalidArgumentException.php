<?php namespace yxorP\app\lib\proxy\exception;
final class invalidArgumentException extends \InvalidArgumentException implements proxyException
{
}
