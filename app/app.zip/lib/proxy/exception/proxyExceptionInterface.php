<?php namespace yxorP\app\lib\proxy\exception;

use Throwable;

interface proxyException extends Throwable
{
}
