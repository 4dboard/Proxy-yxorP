<?php namespace yxorP\app\lib\proxy\promise;
interface promisorInterface
{
    public function promise();
}
