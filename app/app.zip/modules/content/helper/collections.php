<?php

namespace Collections\Helper;

class collections extends \Lime\Helper
{

    public function index()
    {
        return 1;
    }
}
