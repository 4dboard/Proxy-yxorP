// Global Vue components
VueView.component('field-contentItemtLink', 'content:assets/vue-components/field-content-item-link.js');
VueView.component('options-linkModel', 'content:assets/vue-components/options-link-model.js');
