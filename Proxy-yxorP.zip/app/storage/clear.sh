rm -r '/home/sites/19a/5/5b4bb80e9f/public_html/app/storage/cache';
rm -r '/home/sites/19a/5/5b4bb80e9f/public_html/app/storage/tmp';
mkdir '/home/sites/19a/5/5b4bb80e9f/public_html/app/storage/cache' -p;
mkdir '/home/sites/19a/5/5b4bb80e9f/public_html/app/storage/tmp' -p;