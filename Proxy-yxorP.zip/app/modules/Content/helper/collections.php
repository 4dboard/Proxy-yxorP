<?php

namespace Collections\Helper;

class Collections extends \Lime\Helper {

    public function index() {
        return 1;
    }
}