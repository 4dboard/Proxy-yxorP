<?php namespace yxorP\app\lib\proxy\promise;
class cancellationException extends aRejectionException
{
}
