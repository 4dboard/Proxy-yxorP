<?php namespace yxorP\app\lib\proxy\exception;

class tooManyRedirectsException extends aRequestException
{
}
