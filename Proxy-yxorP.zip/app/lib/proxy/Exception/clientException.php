<?php namespace yxorP\app\lib\proxy\exception;
class clientException extends badResponseException
{
}
