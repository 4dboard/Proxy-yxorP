<?php namespace yxorP\app\lib\proxy\exception;

use RuntimeException;

class transferExceptionInterface extends RuntimeException implements proxyException
{
}
