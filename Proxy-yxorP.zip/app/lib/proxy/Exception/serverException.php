<?php namespace yxorP\app\lib\proxy\exception;
class serverException extends badResponseException
{
}
